:- module(tda_section_21247771_VillarroelMontenegro,[section/5,getPoint1/2,getPoint2/2,getdistance/2,getcost/2]).

% Definición de una sección
section(Point1, Point2, Distance, Cost, [Point1, Point2, Distance, Cost]).

% Obtener el punto inicial de una sección
getPoint1([Point1, _, _, _], Point1).

% Obtener el punto final de una sección
getPoint2([_, Point2, _, _], Point2).

% Obtener la distancia de una sección
getdistance([_, _, Distance, _], Distance).

% Obtener el costo de una sección
getcost([_, _, _, Cost], Cost).
