:- use_module(tda_station_21247771_VillarroelMontenegro).
:- use_module(tda_section_21247771_VillarroelMontenegro).
:- use_module(tda_line_21247771_VillarroelMontenegro).
:- use_module(tda_pcar_21247771_VillarroelMontenegro).
:- use_module(tda_train_21247771_VillarroelMontenegro).
:- use_module(tda_driver_21247771_VillarroelMontenegro).
:- use_module(tda_subway_21247771_VillarroelMontenegro).
