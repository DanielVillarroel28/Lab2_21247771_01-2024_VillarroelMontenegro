:- module(tda_line_21247771_VillarroelMontenegro,[line/5,getId/2,getName/2,getRailType/2,getSections/2,sumadis/2,sumacost/2,largo/2,lineAddSection/3,lineLength/4,lineSectionLength/6,find_station_by_name/2,lineSectionLength_helper/7,lineSectionLength_helper2/6,unique_id/2,consistent_sections/1,isLine/1,remove_at/3]).
:- use_module(tda_station_21247771_VillarroelMontenegro).
:- use_module(tda_section_21247771_VillarroelMontenegro).


%Capa Constructor

line(Id,Name,RailType,Sections,[Id,Name,RailType,Sections]).


%Capa Selectora
%
getId(Line,Id):-
    line(Id,_,_,_,Line).

getName(Line,Name):-
    line(_,Name,_,_,Line).

getRailType(Line,RailType):-
    line(_,_,RailType,_,Line).

getSections(Line,Sections):-
    line(_,_,_,Sections,Line).



% Descripcion: Funcion recursiva para sumar todas las distancias de un
% conjunto de secciones de una linea
% Meta Primaria: sumadis/2
% Meta Secundaria:getdistance(Section, Distance)
%                  sumadis(Resto,RestDIstance)
%                  Total Distance is DIstance + Rest Distance



sumadis([], 0).
sumadis([Section|Resto],TotalDistance) :-
    getdistance(Section, Distance),
    sumadis(Resto, RestDistance),
    TotalDistance is Distance + RestDistance.



sumacost([],0).
sumacost([Section|Resto],TotalCost):-
    getcost(Section,Cost),
    sumacost(Resto, RestCost),
    TotalCost is Cost + RestCost.

largo([], 0).
largo([_|Resto], Largo) :-
    largo(Resto, Acc),
    Largo is Acc + 1.


lineLength(Line,Length,Distance,Cost) :-
    getSections(Line,Sections),
    largo(Sections,Length),
    sumacost(Sections,Cost),
    sumadis(Sections,Distance).

lineSectionLength(Line, StartName, EndName, Secciones, TotalDistance, TotalCost) :-
    getSections(Line, Secciones),
    lineSectionLength_helper(StartName, EndName, Secciones, 0, 0, TotalDistance, TotalCost).


lineSectionLength_helper(CurrentStation, EndStation, [Seccion|Resto], DistanceAcc, CostAcc, TotalDistance, TotalCost) :-
    getPoint1(Seccion, AuxCurrent),
    getNameSt(AuxCurrent,Aux2),
    (
        % Verificar si la estación actual coincide con la estación de inicio de la sección
        Aux2 == CurrentStation ->
        (
            getdistance(Seccion, Distance),
            getcost(Seccion, Cost),
            NewDistanceAcc is DistanceAcc + Distance,
            NewCostAcc is CostAcc + Cost,
            lineSectionLength_helper2(EndStation,[Seccion|Resto], NewDistanceAcc, NewCostAcc, TotalDistance, TotalCost)
        )
    ;
        % Si no coincide, continuar con la siguiente sección
        lineSectionLength_helper(CurrentStation, EndStation, Resto, DistanceAcc, CostAcc, TotalDistance, TotalCost)
    ).

lineSectionLength_helper2(EndStation, [Seccion|Resto], DistanceAcc, CostAcc, TotalDistance, TotalCost) :-
    getPoint2(Seccion, AuxNextStation),
    getNameSt(AuxNextStation,Aux3),
    getdistance(Seccion, Distance),
    getcost(Seccion, Cost),
    NDistanceAcc is DistanceAcc + Distance,
    NCostAcc is CostAcc + Cost,


    % Verificar si la estación siguiente es la estación final
    (
        Aux3 == EndStation ->
        (
            % Si es la estación final, asignar la distancia y costo acumulados
            TotalDistance = NDistanceAcc,
            TotalCost = NCostAcc
        )
    ;
        % Si no es la estación final, continuar con la recursión
        lineSectionLength_helper2(EndStation, Resto, NDistanceAcc, NCostAcc, TotalDistance, TotalCost)
    ).


% Predicado para buscar una estación por nombre
find_station_by_name(Name, Station) :-
    station(_, Name, _, _, Station).


lineAddSection(Line,Section,LineOut):-
    getId(Line,Id),
    getName(Line,Name),
    getRailType(Line,RailType),
    getSections(Line,Sections),
    append(Sections, [Section], NewSections),
    line(Id,Name,RailType,NewSections,LineOut).



isSection(Sections):-
    getPoint1(Section,Point1),
    getPoint2(Section,Point2),
    member(Point1, Sections),
    member(Point2, Sections).



% Predicate to check the consistency of a line's sections
consistent_sections([]).
consistent_sections([_]).
consistent_sections([Section1, Section2 | Rest]) :-
    getPoint2(Section1, End1),
    getPoint1(Section2, Start2),
    End1 == Start2,
    consistent_sections([Section2 | Rest]).

% Main predicate to check if a line's ID is unique and sections are consistent
isLine(Line) :-
    % Verify consistency of sections
    getSections(Line, Sections),
    consistent_sections(Sections).

% Predicate to check if a line has a unique ID among a list of lines
unique_id(Line, Lines) :-
    getId(Line, Id),
    \+ (member(OtherLine, Lines), OtherLine \= Line, getId(OtherLine, Id)).


% Predicate to remove a car from a train at a given position
trainRemoveCar(Train, Position, NewTrain) :-
    % Extract the components of the train
    getIdT(Train, Id),
    getMaker(Train, Maker),
    getRailTypeT(Train, RailType),
    getSpeed(Train, Speed),
    getPcars(Train, Pcars),

    % Remove the car at the specified position
    remove_at(Pcars, Position, NewPcars),

    % Construct the new train with the updated list of cars
    train(Id, Maker, RailType, Speed, NewPcars, NewTrain).

% Helper predicate to remove an element at a specific position in a list
remove_at([_|Tail], 0, Tail).
remove_at([Head|Tail], Position, [Head|Rest]) :-
    Position > 0,
    NewPosition is Position - 1,
    remove_at(Tail, NewPosition, Rest).




















