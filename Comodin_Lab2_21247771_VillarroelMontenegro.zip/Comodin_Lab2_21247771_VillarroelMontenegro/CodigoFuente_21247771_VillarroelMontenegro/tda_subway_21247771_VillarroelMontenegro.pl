:- module(tda_subway_212477710_VillarroelMontenegro,[subway/3]).

subway(Id,Nombre,[Id,Nombre]).
