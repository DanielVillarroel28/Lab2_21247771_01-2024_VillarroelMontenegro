:- module(tda_station_21247771_VillarroelMontenegro,[station/5,getNameSt/2]).

station(Id,Name,Type,StopTime,[Id,Name,Type,StopTime]).


getNameSt([_,Name,_,_],Name).



